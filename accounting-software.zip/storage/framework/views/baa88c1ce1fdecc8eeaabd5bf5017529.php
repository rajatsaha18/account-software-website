<?php $__env->startSection('content'); ?>

<section class="py-3">
    <h2 class="text-center mb-5">Blogs</h2>
    <div class="container">

        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="card">
                    <img src="<?php echo e(asset($blog->image)); ?>" alt="blog-image">
                    <div class="card-body">
                        <h4><?php echo e($blog->name); ?></h4>
                        <p>
                            <?php echo $blog->description; ?>

                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp13-11-2024\htdocs\accounting-software\resources\views/website/blog/blog-details.blade.php ENDPATH**/ ?>