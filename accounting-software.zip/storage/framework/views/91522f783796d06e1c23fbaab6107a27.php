<footer class="bg-footer-color text-light py-3 mt-3">
    <div class="container">
        <div class="row">
            <!-- Center text on mobile, left-align on larger screens -->
            <div class="col-12 col-md-6 text-center text-md-start mb-2 mb-md-0">
                <p class="mb-0">© 2024 Your Business Solution. All rights reserved.</p>
            </div>
            <?php
                $footer = DB::table('site_settings')->first();
            ?>

            <!-- Center icons and links on mobile, right-align on larger screens -->
            <div class="col-12 col-md-6 text-center text-md-end">
                <a href="<?php echo e(isset($footer->facebook) ? $footer->facebook : ''); ?>" class="text-light me-3"><i class="fab fa-facebook"></i></a>
                <a href="<?php echo e(isset($footer->twitter) ? $footer->twitter : ''); ?>" class="text-light me-3"><i class="fab fa-twitter"></i></a>
                <a href="<?php echo e(isset($footer->linkedin) ? $footer->linkedin : ''); ?>" class="text-light me-3"><i class="fab fa-linkedin"></i></a>
                <a href="#" class="text-light me-3">Privacy Policy</a>
                <a href="#" class="text-light">Terms of Service</a>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH E:\xampp13-11-2024\htdocs\accounting-software\resources\views/website/layouts/footer.blade.php ENDPATH**/ ?>