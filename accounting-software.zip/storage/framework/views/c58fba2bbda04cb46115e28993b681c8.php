<?php $__env->startSection('title'); ?>
Edit Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="py-2">
    <div class="pc-container">
        <div class="pc-content">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-body">
                        <h3 class="text-center">Edit Product</h3>
                    </div>
                </div>
            </div>
            <section class="py-2">
                <div class="container">
                    <div class="row">
                        <h4 class="text-center text-success"><?php echo e(Session::get('message')); ?></h4>
                        <div class="col-md-6 mx-auto">
                            <div class="card">
                                <div class="card-header">Edit Product</div>
                                <div class="card-body">
                                    <form action="<?php echo e(route('product.update',$product->id)); ?>" method="POST" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group mb-3">
                                            <label for="">Name</label>
                                            <input type="text" value="<?php echo e($product->name); ?>" name="name" class="form-control"/>
                                        </div>
                                        <div class="form-group mb-3">
                                            <label for="">Link</label>
                                            <input type="text" value="<?php echo e($product->name); ?>" name="link" class="form-control"/>
                                        </div>
                                        <div class="form-group mb-3">
                                            <label for="">Image</label>
                                            <input type="file" name="image" class="form-control"/>
                                            <img src="<?php echo e(asset($product->image)); ?>" alt="product-image" style="height: 80px;width:80px;">
                                        </div>
                                        <div class="form-group mb-3">
                                            <label for="">Description</label>
                                            <textarea name="description" id="ckeditor" class="form-control"><?php echo $product->description; ?></textarea>
                                        </div>
                                        <div class="form-group mb-3">
                                            <label for="">status</label>
                                            <select name="status" id="" class="form-control">
                                                <option value="1" <?php echo e($product->status == 1 ? 'selected' : ''); ?>>Active</option>
                                                <option value="0" <?php echo e($product->status == 0 ? 'selected' : ''); ?>>Inactive</option>
                                            </select>
                                        </div>
                                        <div class="form-group mb-3">
                                            <label for=""></label>
                                            <input type="submit" class="btn btn-outline-success"/>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp25-09-24\htdocs\accounting-software\resources\views/admin/product/edit.blade.php ENDPATH**/ ?>