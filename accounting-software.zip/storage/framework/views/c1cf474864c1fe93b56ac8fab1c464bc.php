<?php $__env->startSection('content'); ?>
<style>
    .search-container {
    display: flex;
    align-items: center;
    background-color: #333; /* Dark background color */
    border-radius: 5px;
    width: 300px; /* Adjust width as needed */
    margin-bottom:20px!important;
}

.search-container input {
    border: none;
    padding: 10px;
    width: 100%;
    color: #fff; /* Text color */
    background-color: #333; /* Same background as container */
    border-top-left-radius: 5px;
    border-bottom-left-radius: 5px;
}

.search-container input::placeholder {
    color: #ccc; /* Placeholder text color */
}

.search-container button {
    background-color: #4285F4; /* Button color */
    border: none;
    padding: 10px 15px;
    border-top-right-radius: 5px;
    border-bottom-right-radius: 5px;
    cursor: pointer;
}

.search-container button i {
    color: white;
}
</style>
<section class="py-3">
    <h2 class="text-center mb-5">Blogs</h2>
    <div class="container">
        <form action="<?php echo e(route('blog.search')); ?>" method="GET">
            <div class="search-container">
                <input type="text" name="query" placeholder="Search">
                <button><i class="fa fa-search"></i></button>
            </div>
        </form>
        <?php if($blogs->count() > 0): ?>
        <div class="row">
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-2">
                <div class="card">
                    <img src="<?php echo e(asset($blog->image)); ?>" alt="accounting" class="image-size-product">
                    <div class="card-body">
                        <a href="<?php echo e($blog->link); ?>"><h4 class="text-center"><?php echo e($blog->name); ?></h4></a>
                        <p><?php echo Str::limit($blog->description, 400 ); ?></p>
                        <div class="text-center">
                            <a href="<?php echo e($blog->link); ?>" class="btn btn-primary">Details</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php else: ?>
        <p>No blogs found for your search query.</p>
        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp13-11-2024\htdocs\accounting-software\resources\views/website/blog/blogs-search.blade.php ENDPATH**/ ?>