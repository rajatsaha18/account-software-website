<?php $__env->startSection('title'); ?>
User Message
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="py-2">
    <div class="pc-container">
        <div class="pc-content">
            <div class="row">
                <div class="col-md-12">

                    <div class="card card-body">
                        <h3 class="text-center">Manage User Message</h3>
                    </div>
                </div>
            </div>
            <section>
                <div class="container">
                    <div class="row">
                        <h4 class="text-center text-success"><?php echo e(Session::get('message')); ?></h4>
                        <div class="col-md-12 mx-auto">
                            <div class="card">
                                <div class="card-header text-center">Manage User Message</div>
                                <div class="card-body">
                                    <table class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>Sl</th>
                                                <th>Name</th>
                                                <th>Email</th>
                                                <th>Mobile</th>
                                                <th>Message</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($contact->name); ?></td>
                                                <td><?php echo e($contact->email); ?></td>
                                                <td><?php echo e($contact->mobile); ?></td>
                                                <td><?php echo Str::limit($contact->message, 30); ?></td>
                                                <td>

                                                    <a href="<?php echo e(route('contact.delete',$contact->id)); ?>" class="btn btn-outline-danger btn-sm" onclick="return confirm('Are you sure delete this?')"><i class="fa fa-trash"></i></a>
                                                </td>
                                            </tr>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp13-11-2024\htdocs\accounting-software\resources\views/admin/userMessage/user-message.blade.php ENDPATH**/ ?>