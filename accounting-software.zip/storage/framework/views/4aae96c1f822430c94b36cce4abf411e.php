<footer class="pc-footer">
    <div class="footer-wrapper container-fluid">
        <div class="row">
            <div class="col my-1">
                <p class="m-0">Business Solution &#9829; crafted by Team <a
                        href="" target="_blank"></a>Laravel</p>
            </div>
            <div class="col-auto my-1">
                <ul class="list-inline footer-link mb-0">
                    <li class="list-inline-item"><a href="https://ableproadmin.com/index.html">Home</a></li>
                    <li class="list-inline-item"><a href="https://phoenixcoded.gitbook.io/able-pro/"
                            target="_blank">Documentation</a></li>
                    <li class="list-inline-item"><a href="https://phoenixcoded.authordesk.app/"
                            target="_blank">Support</a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH E:\xampp13-11-2024\htdocs\accounting-software\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>