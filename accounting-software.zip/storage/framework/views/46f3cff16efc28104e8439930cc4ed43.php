<?php $__env->startSection('content'); ?>
<section class="py-3">
    <h2 class="text-center mb-5">Blogs</h2>
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-2">
                <div class="card">
                    <img src="<?php echo e(asset($blog->image)); ?>" alt="accounting" class="image-size-product">
                    <div class="card-body">
                        <a href="<?php echo e($blog->link); ?>"><h4 class="text-center"><?php echo e($blog->name); ?></h4></a>
                        <p><?php echo Str::limit($blog->description, 400 ); ?></p>
                        <div class="text-center">
                            <a href="<?php echo e($blog->link); ?>" class="btn btn-primary">Details</a>
                        </div>
                    </div>
                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp25-09-24\htdocs\accounting-software\resources\views/website/blog/blog-website.blade.php ENDPATH**/ ?>