<?php $__env->startSection('content'); ?>



<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="card-body">
                    <h3 class="text-center">Feeling Good</h3>
                    <p>
                        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Excepturi soluta iure obcaecati debitis dignissimos numquam. Dolores perspiciatis dolor accusamus exercitationem quos veniam, consequuntur illum quis molestias consectetur quia voluptatum blanditiis.
                    </p>
                    <p>
                        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Excepturi soluta iure obcaecati debitis dignissimos numquam. Dolores perspiciatis dolor accusamus exercitationem quos veniam, consequuntur illum quis molestias consectetur quia voluptatum blanditiis.
                    </p>
                    <p>
                        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Excepturi soluta iure obcaecati debitis dignissimos numquam. Dolores perspiciatis dolor accusamus exercitationem quos veniam, consequuntur illum quis molestias consectetur quia voluptatum blanditiis.
                    </p>

                </div>
            </div>

            <div class="col-md-6">
                <h4 class="text-center text-success"><?php echo e(Session::get('message')); ?></h4>
                <div class="card">
                    <div class="card-header text-center">Contact Form</div>
                    <div class="card-body">
                        <form action="<?php echo e(route('contact.form')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="from-group mb-3">
                                <label for="">Name</label>
                                <input type="text" name="name" class="form-control"/>
                                <span class="text-danger"><?php echo e($errors->has('name') ? $errors->first('name') : ''); ?></span>
                            </div>
                            <div class="from-group mb-3">
                                <label for="">Email</label>
                                <input type="email" name="email" class="form-control"/>
                                <span class="text-danger"><?php echo e($errors->has('email') ? $errors->first('email') : ''); ?></span>
                            </div>
                            <div class="from-group mb-3">
                                <label for="">Mobile</label>
                                <input type="mobile" name="mobile" class="form-control"/>
                                <span class="text-danger"><?php echo e($errors->has('mobile') ? $errors->first('mobile') : ''); ?></span>
                            </div>
                            <div class="from-group mb-3">
                                <label for="">Message</label>
                                <textarea name="message" class="form-control"></textarea>
                            </div>
                            <div class="from-group mb-3">
                                <label for=""></label>
                                <input type="submit" class="btn btn-primary" value="Submit"/>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp13-11-2024\htdocs\accounting-software\resources\views/website/home/contact.blade.php ENDPATH**/ ?>