<?php $__env->startSection('title'); ?>
Add Client
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="py-2">
    <div class="pc-container">
        <div class="pc-content">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-body">
                        <h3 class="text-center">Manage Client</h3>
                    </div>
                </div>
            </div>
            <section class="py-2">
                <div class="container">
                    <div class="row">
                        <h4 class="text-center text-success"><?php echo e(Session::get('message')); ?></h4>
                        <div class="col-md-12 mx-auto">
                            <div class="card">
                                <div class="card-header">Manage Client</div>
                                <div class="card-body">
                                    <table class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>Sl</th>
                                                <th>Name</th>
                                                <th>Image</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($Client->name); ?></td>
                                                <td>
                                                    <img src="<?php echo e(asset($Client->image)); ?>" alt="Client-image" style="height:90px; width:100px;"/>
                                                </td>
                                                <td>
                                                    <?php if($Client->status == 1): ?>
                                                    <span class="badge bg-success">Active</span>
                                                    <?php else: ?>
                                                    <span class="badge bg-danger">Inactive</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(route('client.edit',$Client->id)); ?>" class="btn btn-outline-info"><i class="fa fa-edit"></i></a>
                                                    <a href="<?php echo e(route('client.delete',$Client->id)); ?>" class="btn btn-outline-danger" onclick="return confirm('Are you sure delete this?')"><i class="fa fa-trash"></i></a>
                                                </td>
                                            </tr>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                </div>
                                <div>
                                    <?php echo e($clients->links()); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp13-11-2024\htdocs\accounting-software\resources\views/admin/client/manage.blade.php ENDPATH**/ ?>