<?php $__env->startSection('content'); ?>
<h1>Blog</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp25-09-24\htdocs\accounting-software\resources\views/website/home/blog.blade.php ENDPATH**/ ?>