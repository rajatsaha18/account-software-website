<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Accounting Software</title>
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/bootstrap.min.css')); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        body {
            font-family: 'Roboto', sans-serif;
        }

        .navbar-color {
            background-color: #4834d4;

        }
        .text_color{
            color: white!important;
        }

        .image-size {
            height: 180px !important;
            width: 100% !important;
        }
        .image-size-product {
            height: 250px !important;
        }

        .carousel-item img {
            margin: auto;
        }

        .bg-footer-color {
            background-color: #4834d4 !important;
        }

        @media (max-width: 768px) {
            .image-size {
                height: 150px !important;
            }
        }
    </style>
</head>

<body>
    <!--Navbar Start-->
    <?php echo $__env->make('website.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--Navbar End-->

    <!--Main Body-->

    <?php echo $__env->yieldContent('content'); ?>

    <!--Main Body-->

    <!--Footer Start-->
    <?php echo $__env->make('website.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--Footer End-->

    <script src="<?php echo e(asset('public/assets/js/jquery-3.7.1.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/js/bootstrap.bundle.min.js')); ?>"></script>

</body>

</html>
<?php /**PATH E:\xampp25-09-24\htdocs\accounting-software\resources\views/website/layouts/master.blade.php ENDPATH**/ ?>