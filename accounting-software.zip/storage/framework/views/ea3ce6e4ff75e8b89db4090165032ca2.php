<?php $__env->startSection('content'); ?>


<section class="">
    <div class="row">
        <div class="col-md-12 ">
            <div class="card card-body bg-primary">
                <h3 class="text-center text-light">Contact</h3>
            </div>
        </div>
    </div>

</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp25-09-24\htdocs\accounting-software\resources\views/website/home/contact.blade.php ENDPATH**/ ?>