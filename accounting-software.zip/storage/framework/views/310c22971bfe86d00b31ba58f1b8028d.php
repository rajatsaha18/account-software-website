<?php $__env->startSection('title'); ?>
Add Blog
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="py-2">
    <div class="pc-container">
        <div class="pc-content">
            <div class="row">
                <div class="col-md-12">

                    <div class="card card-body">
                        <h3 class="text-center">Manage Blog</h3>
                    </div>
                </div>
            </div>
            <section>
                <div class="container">
                    <div class="row">
                        <h4 class="text-center text-success"><?php echo e(Session::get('message')); ?></h4>
                        <div class="col-md-12 mx-auto">
                            <div class="text-end">
                                <a href="<?php echo e(route('blog.add')); ?>" class="btn btn-success mb-2">Add Blog</a>
                            </div>
                            <div class="card">
                                <div class="card-header text-center">Manage Blog</div>
                                <div class="card-body">
                                    <table class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>Sl</th>
                                                <th>Name</th>
                                                <th>Image</th>
                                                <th>Description</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($Blog->name); ?></td>
                                                <td>
                                                    <img src="<?php echo e(asset($Blog->image)); ?>" alt="Blog-image" style="height:70px; width:70px;"/>
                                                </td>
                                                <td><?php echo Str::limit($Blog->description, 50); ?></td>
                                                <td>
                                                    <?php if($Blog->status == 1): ?>
                                                    <span class="badge bg-success">Active</span>
                                                    <?php else: ?>
                                                    <span class="badge bg-danger">Inactive</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(route('blog.edit',$Blog->id)); ?>" class="btn btn-outline-info btn-sm"><i class="fa fa-edit"></i></a>
                                                    <a href="<?php echo e(route('blog.delete',$Blog->id)); ?>" class="btn btn-outline-danger btn-sm" onclick="return confirm('Are you sure delete this?')"><i class="fa fa-trash"></i></a>
                                                </td>
                                            </tr>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp25-09-24\htdocs\accounting-software\resources\views/admin/blog/manage.blade.php ENDPATH**/ ?>